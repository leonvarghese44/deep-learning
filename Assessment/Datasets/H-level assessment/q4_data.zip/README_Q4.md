# Question 4 data: hand outline completion

All coordinates are `float32` (x, y) pairs. Each outline runs from the thumb-side wrist,
clockwise round the hand, to the little-finger-side wrist, with points equally spaced along it.
Each outline has had its own random rotation, scaling and translation applied.

Because outlines and gaps have different lengths, the points of all outlines (or all gaps) are
stored packed end to end in a single array, with a separate array of lengths.

## `q4_train.npz`: 8,000 complete outlines

| key       | shape          | meaning                                            |
|-----------|----------------|----------------------------------------------------|
| `points`  | (ΣN, 2) float32 | all outlines, packed end to end                   |
| `lengths` | (8000,) int32   | number of points N in each outline                |
| `delta`   | (8000,) float32 | spacing between consecutive points of each outline |

## `q4_val.npz`: 1,000 completion problems

| key                                  | shape            | meaning                                         |
|--------------------------------------|------------------|-------------------------------------------------|
| `before`, `missing`, `after`         | (Σn, 2) float32  | packed points before the gap, in the gap, after it |
| `n_before`, `n_missing`, `n_after`   | (1000,) int32    | number of points in each part of each problem   |
| `delta`                              | (1000,) float32  | point spacing of each problem's outline         |

For each problem, `before`, then `missing`, then `after` is the complete outline. The unseen
test problems are made in the same way. In marking, δ is the true spacing of each outline, which
you can estimate very accurately from the points you are given.

## Loading

```python
import numpy as np

d = np.load("q4_train.npz")
outlines = np.split(d["points"], np.cumsum(d["lengths"])[:-1])   # list of (N, 2) arrays

v = np.load("q4_val.npz")
def unpack(key):
    return np.split(v[key], np.cumsum(v["n_" + key])[:-1])
before, missing, after = unpack("before"), unpack("missing"), unpack("after")
```
