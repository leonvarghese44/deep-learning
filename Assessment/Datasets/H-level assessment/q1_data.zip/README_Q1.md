# Q1 Shape Recognition: data

All images are **uint8** arrays of shape `N x 3 x 32 x 32` (channels first, RGB).
Divide by 255 to obtain intensities in [0, 1], the format `predict()` receives.

| file | key | shape | dtype | notes |
|------|-----|-------|-------|-------|
| `q1_train.npz` | `images` | 6000 x 3 x 32 x 32 | uint8 | |
| | `labels` | 6000 | int64 | as given by the annotator (may contain errors) |
| | `annotator` | 6000 | int64 | id (0-5) of the annotator who labelled the image |
| `q1_val.npz` | `images` | 900 x 3 x 32 x 32 | uint8 | |
| | `labels` | 900 | int64 | verified labels |
| | `masks` | 900 x 32 x 32 | bool | True on pixels belonging to the shape |
| `q1_dev.npz` | `images` | 200 x 3 x 32 x 32 | uint8 | different collection session |
| | `labels` | 200 | int64 | verified labels |

```python
import numpy as np
d = np.load("q1_train.npz")
x, y, a = d["images"], d["labels"], d["annotator"]
```

## Label indices

| index | shape |
|-------|-------|
| 0 | circle |
| 1 | triangle |
| 2 | square |
| 3 | pentagon |
| 4 | hexagon |
| 5 | star |
| 6 | cross |
| 7 | crescent |
| 8 | heart |
| 9 | arrow |
