# Q3 Scene Segmentation: data

Images are **uint8** arrays `N x 3 x 64 x 64` (channels first, RGB); divide by 255 to get
intensities in [0, 1], the format `predict()` receives. Label maps are `N x 64 x 64` uint8.

| file | key | shape | notes |
|------|-----|-------|-------|
| `q3_train_labelled.npz` | `images` | 600 x 3 x 64 x 64 | |
| | `labels` | 600 x 64 x 64 | per-pixel class map (ids below), as drawn by the annotator |
| | `instances` | 600 x 64 x 64 | per-pixel object-instance map: 0 = no object, 1..k = objects in that scene |
| | `annotator` | 600 | id (0-5) of the annotator who annotated the scene |
| `q3_train_unlabelled.npz` | `images` | 3000 x 3 x 64 x 64 | no annotation |
| `q3_val.npz` | `images`, `labels`, `instances` | 200 scenes | verified annotation |
| `q3_dev.npz` | `images`, `labels`, `instances` | 60 scenes | verified annotation, different collection session |

Only the **visible** pixels of an object carry its label. Label 0 (background) also covers
look-alike clutter shapes that are not one of the 5 object classes.

```python
import numpy as np
d = np.load("q3_train_labelled.npz")
x, y, inst, ann = d["images"], d["labels"], d["instances"], d["annotator"]
```

## Label ids

| id | class |
|----|-------|
| 0 | background |
| 1 | disc |
| 2 | ring |
| 3 | triangle |
| 4 | star |
| 5 | bar |
